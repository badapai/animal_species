#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

def talker():
    # Publisher for images
    pub = rospy.Publisher('frames', Image, queue_size=10)
    
    # Initialize node
    rospy.init_node('image_publisher', anonymous=True)
    
    # Set rate
    rate = rospy.Rate(1)  # 10hz
    
    # CvBridge to convert OpenCV images to ROS Image messages
    bridge = CvBridge()
    
    # Load your image (replace with your own image path)
    img1 = cv2.imread('/home/newrro_arjuna_1/Downloads/happy_face.jpg')  # BGR format
    img2 = cv2.imread('/home/newrro_arjuna_1/Downloads/sad_face.jpeg')  # BGR format
    
    if img1 is None:
        rospy.logerr("Could not read image!")
        return
    
    while not rospy.is_shutdown():
        # Convert OpenCV image to ROS Image message
        ros_img1 = bridge.cv2_to_imgmsg(img1, encoding="bgr8")
        ros_img2 = bridge.cv2_to_imgmsg(img2, encoding="bgr8")
        # Publish
        pub.publish(ros_img1)
        
        rospy.loginfo("Published an image")
        rate.sleep()
        
        pub.publish(ros_img2)
        
        rospy.loginfo("Published an image")
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass

