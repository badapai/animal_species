#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
import cv2
import numpy as np
from keras.models import load_model

# Initialize CvBridge
bridge = CvBridge()

# Load face detector and emotion model once
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
emotion_model = load_model('/home/newrro_arjuna_1/bmsce/src/emotions/scripts/emotion_model.h5', compile=False)
emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']

def callback(msg):
    try:
        # Convert ROS Image message to OpenCV image
        frame = bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect faces
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

        for (x, y, w, h) in faces:
            roi_gray = gray[y:y+h, x:x+w]
            roi_gray = cv2.resize(roi_gray, (64, 64))
            roi = roi_gray.astype('float32') / 255.0
            roi = np.expand_dims(roi, axis=0)
            roi = np.expand_dims(roi, axis=-1)

            # Predict emotion
            prediction = emotion_model.predict(roi, verbose=0)
            emotion = emotion_labels[np.argmax(prediction)]

            # Draw rectangle and label
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(frame, emotion, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX,
                        0.9, (36, 255, 12), 2)

            # Publish emotion
            pub.publish(emotion)

        # Display the frame
        cv2.imshow('Emotion Detection', frame)
        cv2.waitKey(1)

    except Exception as e:
        rospy.logerr("Error in callback: %s", e)

if __name__ == '__main__':
    rospy.init_node('emotion_listener', anonymous=True)

    # Publisher for emotions
    pub = rospy.Publisher('emotion_pub', String, queue_size=10)

    # Subscriber for frames
    rospy.Subscriber('frames', Image, callback)

    rospy.spin()

